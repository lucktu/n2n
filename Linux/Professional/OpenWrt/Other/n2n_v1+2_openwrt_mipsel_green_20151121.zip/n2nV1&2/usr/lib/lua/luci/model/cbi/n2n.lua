
m = Map("n2n", translate("N2N VPN (V1)"),translate("n2n is a layer-two peer-to-peer virtual private network (VPN) which allows users to exploit features typical of P2P applications at network instead of application level."))

s = m:section(TypedSection, "edge", translate("edge"))
s.addremove = true
s.anonymous = false
s:option(Flag, "enabled", translate("Enable"))

tunname=s:option(Value,"tunname",translate("TUN desvice name"))
tunname.optional=false
s:option(Value, "supernode", translate("Supernode IP address")).rmempty = true
s:option(Value, "port", translate("Supernode Port")).rmempty = true
s:option(Value, "community", translate("N2N Community name")).rmempty = true
key=s:option(Value, "key", translate("Key"))
key.password = true
key.rmempty = true

s:option(Value, "ipaddr", translate("Interface IP address")).rmempty = true
s:option(Value, "mtu", translate("Specify n2n MTU (default 1400)")).rmempty = true
s:option(Flag, "renew", translate("Renew (when supernodes are running on dynamic IPs)")).rmempty = true
s:option(Flag, "route", translate("Enable packet forwarding")).rmempty = true

supernode = m:section(TypedSection, "supernode", translate("supernode"))
supernode:option(Flag, "enabled", translate("Enable"))
supernode:option(Value, "port", translate("port")).rmempty = true
supernode.addremove = true
supernode.anonymous = false

return m
