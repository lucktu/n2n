
## 安装
```bash
sudo cp lomot.n2n.edge.plist /Library/LaunchDaemons/
mkdir -p /usr/local/etc/n2n/
cp conf/edge.conf /usr/local/etc/n2n/
```

## 开启服务
```bash
launchctl load /Library/LaunchDaemons/lomot.n2n.edge.plist
```

## 关闭服务
```bash
launchctl unload /Library/LaunchDaemons/lomot.n2n.edge.plist
```

